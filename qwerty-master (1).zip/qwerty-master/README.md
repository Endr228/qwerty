# qwerty
Скачать архив и изменить данные
Команды для установки

pkg install nodejs

pkg intall nodejs-lst

cd папка

ls

sh install .sh

----
дальнейший запуск

cd папка

sh kek.sh
