npm install colors
npm install vk-io
node 1